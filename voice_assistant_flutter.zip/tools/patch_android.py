"""Patches the freshly generated Flutter android project: permissions, queries, label, proguard."""
import os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
p = os.path.join(root, "android/app/src/main/AndroidManifest.xml")
s = open(p, encoding="utf-8").read()

perms = (
    '\n    <uses-permission android:name="android.permission.RECORD_AUDIO"/>'
    '\n    <uses-permission android:name="com.android.alarm.permission.SET_ALARM"/>'
)
if "RECORD_AUDIO" not in s:
    s = re.sub(r"(<manifest[^>]*>)", lambda m: m.group(1) + perms, s, count=1)

q = (
    '\n        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>'
    '\n        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>'
    '\n        <intent><action android:name="android.intent.action.DIAL"/></intent>\n'
)
if "TTS_SERVICE" not in s:
    if "</queries>" in s:
        s = s.replace("</queries>", q + "    </queries>", 1)
    else:
        s = s.replace("</manifest>", "    <queries>" + q + "    </queries>\n</manifest>", 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="Voice Assistant"', s, count=1)
open(p, "w", encoding="utf-8").write(s)

rules = os.path.join(root, "android/app/proguard-rules.pro")
open(rules, "w").write(
    "-keep class com.sun.jna.* { *; }\n"
    "-keepclassmembers class * extends com.sun.jna.* { public *; }\n"
)
print("patched:", p)
