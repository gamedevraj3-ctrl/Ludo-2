import 'package:android_intent_plus/android_intent.dart';
import 'package:url_launcher/url_launcher.dart';

enum Lang { hi, en }

class Reply {
  Reply(this.text, {this.action});
  final String text;
  final Future<void> Function()? action;
}

class _App {
  const _App(this.keys, this.label, {this.pkg, this.action});
  final List<String> keys;
  final String label;
  final String? pkg;
  final String? action;
}

/// Offline "brain": commands + small talk. No internet, no AI model.
class Brain {
  static const _hiDays = ['सोमवार', 'मंगलवार', 'बुधवार', 'गुरुवार', 'शुक्रवार', 'शनिवार', 'रविवार'];
  static const _enDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  static const _hiMonths = ['जनवरी', 'फरवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'];
  static const _enMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  static const _apps = <_App>[
    _App(['youtube', 'यूट्यूब', 'यू ट्यूब'], 'YouTube', pkg: 'com.google.android.youtube'),
    _App(['whatsapp', 'whats app', 'व्हाट्सएप', 'व्हाट्सऐप', 'वॉट्सऐप'], 'WhatsApp', pkg: 'com.whatsapp'),
    _App(['chrome', 'क्रोम'], 'Chrome', pkg: 'com.android.chrome'),
    _App(['instagram', 'इंस्टाग्राम'], 'Instagram', pkg: 'com.instagram.android'),
    _App(['maps', 'map', 'मैप', 'मैप्स'], 'Maps', pkg: 'com.google.android.apps.maps'),
    _App(['gallery', 'photos', 'गैलरी', 'फोटो'], 'Photos', pkg: 'com.google.android.apps.photos'),
    _App(['camera', 'कैमरा'], 'Camera', action: 'android.media.action.STILL_IMAGE_CAMERA'),
    _App(['settings', 'setting', 'सेटिंग', 'सेटिंग्स'], 'Settings', action: 'android.settings.SETTINGS'),
    _App(['wifi', 'वाईफाई', 'वाई फाई'], 'Wi-Fi settings', action: 'android.settings.WIFI_SETTINGS'),
    _App(['bluetooth', 'ब्लूटूथ'], 'Bluetooth settings', action: 'android.settings.BLUETOOTH_SETTINGS'),
    _App(['phone', 'dialer', 'फोन', 'डायलर'], 'Phone', action: 'android.intent.action.DIAL'),
  ];

  static const _numWords = <String, int>{
    'ek': 1, 'one': 1, 'एक': 1, 'do': 2, 'two': 2, 'दो': 2, 'teen': 3, 'three': 3, 'तीन': 3,
    'char': 4, 'four': 4, 'चार': 4, 'paanch': 5, 'panch': 5, 'five': 5, 'पांच': 5, 'पाँच': 5,
    'chhe': 6, 'che': 6, 'six': 6, 'छह': 6, 'छः': 6, 'saat': 7, 'seven': 7, 'सात': 7,
    'aath': 8, 'eight': 8, 'आठ': 8, 'nau': 9, 'nine': 9, 'नौ': 9, 'das': 10, 'ten': 10, 'दस': 10,
    'pandrah': 15, 'fifteen': 15, 'पंद्रह': 15, 'bees': 20, 'twenty': 20, 'बीस': 20,
    'tees': 30, 'thirty': 30, 'तीस': 30, 'chalis': 40, 'forty': 40, 'चालीस': 40,
    'pachaas': 50, 'fifty': 50, 'पचास': 50,
  };

  Reply handle(String raw, Lang lang) {
    final hi = lang == Lang.hi;
    final t = _norm(raw);
    if (t.isEmpty) {
      return Reply(hi ? 'मुझे कुछ सुनाई नहीं दिया।' : 'Mujhe kuch sunai nahi diya.');
    }

    // ---- math: "5 plus 3"
    final m = RegExp(r'(\d+(?:\.\d+)?)\s*(plus|\+|jod|जोड़|जोड|minus|-|ghata|घटा|into|x|guna|गुणा|times|divide|by|bhag|भाग)\s*(\d+(?:\.\d+)?)').firstMatch(t);
    if (m != null) {
      final a = double.parse(m.group(1)!);
      final b = double.parse(m.group(3)!);
      final op = m.group(2)!;
      double? r;
      if (['plus', '+', 'jod', 'जोड़', 'जोड'].contains(op)) r = a + b;
      if (['minus', '-', 'ghata', 'घटा'].contains(op)) r = a - b;
      if (['into', 'x', 'guna', 'गुणा', 'times'].contains(op)) r = a * b;
      if (['divide', 'by', 'bhag', 'भाग'].contains(op) && b != 0) r = a / b;
      if (r != null) {
        final s = r == r.roundToDouble() ? r.toInt().toString() : r.toStringAsFixed(2);
        return Reply(hi ? 'जवाब है $s।' : 'Jawab hai $s.');
      }
    }

    // ---- timer
    if (_has(t, ['timer', 'टाइमर'])) {
      final secs = _duration(t);
      if (secs > 0) {
        final label = _durationLabel(secs, hi);
        return Reply(
          hi ? '$label का टाइमर लगा रही हूँ।' : '$label ka timer laga raha hoon.',
          action: () => AndroidIntent(
            action: 'android.intent.action.SET_TIMER',
            arguments: <String, dynamic>{
              'android.intent.extra.alarm.LENGTH': secs,
              'android.intent.extra.alarm.SKIP_UI': true,
            },
          ).launch(),
        );
      }
      return Reply(hi ? 'कितने मिनट का टाइमर लगाऊँ?' : 'Kitne minute ka timer lagaun?');
    }

    // ---- alarm
    if (_has(t, ['alarm', 'अलार्म'])) {
      final hm = _clock(t);
      if (hm != null) {
        final hh = hm[0];
        final mm = hm[1];
        final txt = '$hh:${mm.toString().padLeft(2, '0')}';
        return Reply(
          hi ? '$txt बजे का अलार्म लगा रही हूँ।' : '$txt baje ka alarm laga raha hoon.',
          action: () => AndroidIntent(
            action: 'android.intent.action.SET_ALARM',
            arguments: <String, dynamic>{
              'android.intent.extra.alarm.HOUR': hh,
              'android.intent.extra.alarm.MINUTES': mm,
              'android.intent.extra.alarm.SKIP_UI': true,
            },
          ).launch(),
        );
      }
      return Reply(hi ? 'कितने बजे का अलार्म लगाऊँ?' : 'Kitne baje ka alarm lagaun?');
    }

    // ---- time / date
    final now = DateTime.now();
    if (_has(t, ['kitne baje', 'time kya', 'what time', 'समय', 'कितने बजे', 'टाइम क्या', 'samay', 'abhi time'])) {
      final h12 = now.hour % 12 == 0 ? 12 : now.hour % 12;
      final mm = now.minute.toString().padLeft(2, '0');
      return Reply(hi ? 'अभी $h12:$mm बजे हैं।' : 'Abhi $h12:$mm baje hain.');
    }
    if (_has(t, ['date', 'tarikh', 'taareekh', 'aaj kya din', 'what day', 'तारीख', 'तारिख', 'दिनांक', 'आज कौन सा दिन', 'कौन सा दिन'])) {
      final wd = (hi ? _hiDays : _enDays)[now.weekday - 1];
      final mo = (hi ? _hiMonths : _enMonths)[now.month - 1];
      return Reply(hi ? 'आज $wd है, ${now.day} $mo ${now.year}।' : 'Aaj $wd hai, ${now.day} $mo ${now.year}.');
    }

    // ---- call
    if (_has(t, ['call', 'कॉल', 'कोल', 'phone karo', 'फोन करो'])) {
      final digits = RegExp(r'\d[\d ]{6,}\d').firstMatch(t)?.group(0)?.replaceAll(' ', '');
      if (digits != null) {
        return Reply(
          hi ? '$digits पर कॉल लगा रही हूँ।' : '$digits par call laga raha hoon.',
          action: () => launchUrl(Uri(scheme: 'tel', path: digits), mode: LaunchMode.externalApplication),
        );
      }
      return Reply(hi ? 'कौन सा नंबर मिलाऊँ? नंबर बोलिए।' : 'Kaun sa number milaun? Number bolo.');
    }

    // ---- open apps
    if (_has(t, ['open', 'kholo', 'khol', 'chalu', 'start', 'खोलो', 'खोल', 'ओपन', 'चालू', 'चलाओ'])) {
      for (final a in _apps) {
        if (_has(t, a.keys)) {
          return Reply(
            hi ? '${a.label} खोल रही हूँ।' : '${a.label} khol raha hoon.',
            action: () {
              if (a.pkg != null) {
                return AndroidIntent(
                  action: 'android.intent.action.MAIN',
                  category: 'android.intent.category.LAUNCHER',
                  package: a.pkg,
                ).launch();
              }
              return AndroidIntent(action: a.action!).launch();
            },
          );
        }
      }
      return Reply(hi ? 'कौन सा ऐप खोलूँ?' : 'Kaun sa app kholun?');
    }

    // ---- small talk
    if (_has(t, ['hello', 'hi ', 'hey', 'namaste', 'namaskar', 'नमस्ते', 'नमस्कार', 'हेलो', 'हैलो']) || t == 'hi') {
      return Reply(hi ? 'नमस्ते! मैं आपकी क्या मदद करूँ?' : 'Namaste! Main aapki kya madad karun?');
    }
    if (_has(t, ['kaise ho', 'how are you', 'कैसे हो', 'कैसी हो', 'क्या हाल'])) {
      return Reply(hi ? 'मैं बढ़िया हूँ, शुक्रिया! आप कैसे हैं?' : 'Main badhiya hoon, shukriya! Aap kaise ho?');
    }
    if (_has(t, ['tum kaun', 'who are you', 'tumhara naam', 'your name', 'तुम कौन', 'आप कौन', 'तुम्हारा नाम', 'आपका नाम'])) {
      return Reply(hi ? 'मैं आपकी ऑफलाइन वॉइस असिस्टेंट हूँ। मुझे चलने के लिए इंटरनेट नहीं चाहिए।' : 'Main aapki offline voice assistant hoon. Mujhe chalne ke liye internet nahi chahiye.');
    }
    if (_has(t, ['thank', 'shukriya', 'dhanyavad', 'थैंक', 'शुक्रिया', 'धन्यवाद'])) {
      return Reply(hi ? 'आपका स्वागत है!' : 'Aapka swagat hai!');
    }
    if (_has(t, ['joke', 'chutkula', 'चुटकुला', 'जोक'])) {
      final jokes = hi
          ? ['टीचर ने पूछा, सबसे तेज़ चीज़ क्या है? बच्चा बोला, रिज़ल्ट, क्योंकि सब कुछ आने से पहले ही पता चल जाता है।', 'पप्पू ने फोन चार्ज पर लगाया और बोला, अब तू भी थोड़ा आराम कर ले।']
          : ['Teacher ne pucha, sabse tez kya hai? Bachcha bola, result, kyunki aane se pehle hi sabko pata chal jata hai.', 'Pappu ne phone charge par lagaya aur bola, ab tu bhi thoda aaram kar le.'];
      return Reply(jokes[now.second % jokes.length]);
    }
    if (_has(t, ['help', 'madad', 'kya kar sakti', 'kya kar sakte', 'मदद', 'क्या कर सकती', 'क्या कर सकते'])) {
      return Reply(hi
          ? 'मैं समय, तारीख, टाइमर, अलार्म, कॉल और ऐप खोलना कर सकती हूँ। जोड़ घटाना भी आता है।'
          : 'Main time, date, timer, alarm, call aur app kholna kar sakti hoon. Jod ghata bhi aata hai.');
    }

    return Reply(hi
        ? 'माफ़ कीजिए, मुझे इसका जवाब नहीं पता। बाद में ऑफलाइन AI मॉडल जुड़ने पर मैं और सवाल समझ पाऊँगी।'
        : 'Sorry, mujhe iska jawab nahi pata. Baad mein offline AI model judne par main aur sawaal samajh paungi.');
  }

  // ---------- helpers
  static String _norm(String s) {
    var t = s.toLowerCase();
    const dev = '०१२३४५६७८९';
    for (var i = 0; i < dev.length; i++) {
      t = t.replaceAll(dev[i], i.toString());
    }
    t = t.replaceAll(RegExp(r'[,.!?।;]'), ' ');
    t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
    return t;
  }

  static bool _has(String t, List<String> keys) {
    final padded = ' $t ';
    for (final k in keys) {
      if (padded.contains(k)) return true;
    }
    return false;
  }

  static int _unit(String w) {
    if (['sec', 'second', 'seconds', 'सेकंड', 'सेकण्ड', 'सैकंड'].contains(w)) return 1;
    if (['min', 'minute', 'minutes', 'mins', 'मिनट', 'मिनिट'].contains(w)) return 60;
    if (['hour', 'hours', 'ghanta', 'ghante', 'ghanta', 'घंटा', 'घंटे', 'घण्टे', 'घण्टा'].contains(w)) return 3600;
    return 0;
  }

  static int _duration(String t) {
    final tok = t.split(' ');
    var total = 0;
    int? lastNum;
    for (var i = 0; i < tok.length; i++) {
      final w = tok[i];
      final n = int.tryParse(w) ?? _numWords[w];
      if (n != null) {
        lastNum = n;
        if (i + 1 < tok.length) {
          final u = _unit(tok[i + 1]);
          if (u > 0) {
            total += n * u;
            lastNum = null;
          }
        }
      }
    }
    if (total == 0 && lastNum != null) total = lastNum * 60;
    return total;
  }

  static String _durationLabel(int secs, bool hi) {
    final h = secs ~/ 3600;
    final m = (secs % 3600) ~/ 60;
    final s = secs % 60;
    final parts = <String>[];
    if (h > 0) parts.add(hi ? '$h घंटे' : '$h ghante');
    if (m > 0) parts.add(hi ? '$m मिनट' : '$m minute');
    if (s > 0) parts.add(hi ? '$s सेकंड' : '$s second');
    return parts.join(' ');
  }

  static List<int>? _clock(String t) {
    final m = RegExp(r'(\d{1,2})(?:[: ](\d{2}))?').firstMatch(t);
    var h = m != null ? int.parse(m.group(1)!) : _numberWord(t);
    if (h == null || h > 23) return null;
    final mm = m?.group(2) != null ? int.parse(m!.group(2)!) : 0;
    final pm = _has(t, ['pm', 'shaam', 'sham', 'raat', 'शाम', 'रात', 'dopahar', 'दोपहर']);
    if (pm && h < 12) h += 12;
    return [h, mm > 59 ? 0 : mm];
  }

  static int? _numberWord(String t) {
    for (final w in t.split(' ')) {
      final n = _numWords[w];
      if (n != null && n <= 12) return n;
    }
    return null;
  }
}
