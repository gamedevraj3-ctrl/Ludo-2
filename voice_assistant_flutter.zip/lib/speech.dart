import 'dart:async';
import 'dart:convert';

import 'package:flutter_tts/flutter_tts.dart';
import 'package:vosk_flutter/vosk_flutter.dart';

import 'brain.dart';

/// Offline speech-to-text using Vosk (models are bundled in assets/models).
class SttService {
  final VoskFlutterPlugin _vosk = VoskFlutterPlugin.instance();
  final Map<Lang, Model> _models = {};
  Recognizer? _recognizer;
  SpeechService? _service;
  StreamSubscription<String>? _partialSub;
  StreamSubscription<String>? _resultSub;

  static const _modelAsset = {
    Lang.hi: 'assets/models/vosk-model-small-hi-0.22.zip',
    Lang.en: 'assets/models/vosk-model-small-en-in-0.4.zip',
  };

  Future<void> load(
    Lang lang, {
    required void Function(String) onPartial,
    required void Function(String) onFinal,
  }) async {
    await release();
    var model = _models[lang];
    if (model == null) {
      final path = await ModelLoader().loadFromAssets(_modelAsset[lang]!);
      model = await _vosk.createModel(path);
      _models[lang] = model;
    }
    _recognizer = await _vosk.createRecognizer(model: model, sampleRate: 16000);
    _service = await _vosk.initSpeechService(_recognizer!);
    _partialSub = _service!.onPartial().listen((s) {
      final t = _field(s, 'partial');
      if (t.isNotEmpty) onPartial(t);
    });
    _resultSub = _service!.onResult().listen((s) {
      final t = _field(s, 'text');
      if (t.isNotEmpty) onFinal(t);
    });
  }

  Future<void> start() async {
    await _service?.start();
  }

  Future<void> stop() async {
    await _service?.stop();
  }

  Future<void> release() async {
    await _partialSub?.cancel();
    await _resultSub?.cancel();
    _partialSub = null;
    _resultSub = null;
    try {
      await _service?.stop();
    } catch (_) {}
    try {
      await _service?.dispose();
    } catch (_) {}
    _service = null;
    _recognizer = null;
  }

  static String _field(String json, String key) {
    try {
      final m = jsonDecode(json);
      if (m is Map && m[key] is String) return (m[key] as String).trim();
    } catch (_) {}
    return '';
  }
}

/// Offline text-to-speech using the phone's own TTS engine.
class VoiceService {
  final FlutterTts _tts = FlutterTts();

  Future<void> init() async {
    await _tts.awaitSpeakCompletion(true);
    await _tts.setSpeechRate(0.5);
    await _tts.setPitch(1.0);
  }

  Future<void> speak(String text, Lang lang, {void Function()? onProgress}) async {
    await _tts.setLanguage(lang == Lang.hi ? 'hi-IN' : 'en-IN');
    _tts.setProgressHandler((String t, int start, int end, String word) {
      onProgress?.call();
    });
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }
}
