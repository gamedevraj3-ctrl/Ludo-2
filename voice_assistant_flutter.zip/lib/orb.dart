import 'dart:math';

import 'package:flutter/material.dart';

enum OrbState { loading, idle, listening, thinking, speaking }

/// Holds time/level/state. The painter repaints whenever this notifies.
class OrbController extends ChangeNotifier {
  double t = 0;
  double level = 0;
  OrbState state = OrbState.loading;
  Color accent = const Color(0xFF6C8BFF);

  void update(double time, double lv, OrbState st) {
    t = time;
    level = lv;
    state = st;
    notifyListeners();
  }
}

class _Blob {
  const _Blob(this.color, this.phase, this.speed);
  final Color color;
  final double phase;
  final double speed;
}

class OrbPainter extends CustomPainter {
  OrbPainter(this.c) : super(repaint: c);
  final OrbController c;

  static const _blobs = <_Blob>[
    _Blob(Color(0xFF6C8BFF), 0.0, 1.0),
    _Blob(Color(0xFF9B6CFF), 2.1, -0.8),
    _Blob(Color(0xFF38E1FF), 4.2, 1.3),
    _Blob(Color(0xFFFF7AD9), 1.0, -1.1),
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final t = c.t;
    final lv = c.level;
    final st = c.state;
    final ctr = size.center(Offset.zero);
    final base = size.shortestSide * 0.26;
    final active = st == OrbState.listening || st == OrbState.speaking;
    double energy;
    switch (st) {
      case OrbState.listening:
        energy = 0.25 + lv * 0.75;
        break;
      case OrbState.speaking:
        energy = 0.25 + lv * 0.7;
        break;
      case OrbState.thinking:
        energy = 0.35;
        break;
      case OrbState.loading:
        energy = 0.2;
        break;
      case OrbState.idle:
        energy = 0.08;
        break;
    }
    final r = base * (1 + 0.035 * sin(t * 1.6) + energy * 0.10 * sin(t * 7.3) + lv * 0.08);

    // soft halo
    final haloRect = Rect.fromCircle(center: ctr, radius: r * 2.4);
    canvas.drawCircle(
      ctr,
      r * 2.4,
      Paint()
        ..shader = RadialGradient(
          colors: [c.accent.withValues(alpha: 0.35 * (0.4 + energy)), Colors.transparent],
        ).createShader(haloRect),
    );

    // expanding rings
    if (active || st == OrbState.thinking) {
      for (var i = 0; i < 3; i++) {
        final ph = (t * (0.5 + energy * 0.8) + i / 3) % 1.0;
        canvas.drawCircle(
          ctr,
          r * (1.05 + ph * 0.9),
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2
            ..color = Colors.white.withValues(alpha: (1 - ph) * 0.30),
        );
      }
    }

    // body
    final body = Rect.fromCircle(center: ctr, radius: r);
    canvas.save();
    canvas.clipPath(Path()..addOval(body));
    canvas.drawCircle(
      ctr,
      r,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.3, -0.4),
          radius: 1.1,
          colors: [Color(0xFF2B3A7A), Color(0xFF0B1030)],
        ).createShader(body),
    );
    for (var i = 0; i < _blobs.length; i++) {
      final b = _blobs[i];
      final a = t * (0.6 + energy * 1.8) * b.speed + b.phase;
      final d = r * (0.28 + 0.22 * energy);
      final p = ctr + Offset(cos(a), sin(a * 1.3)) * d;
      canvas.drawCircle(
        p,
        r * (0.55 + 0.12 * sin(t * 2 + i) + energy * 0.15),
        Paint()
          ..color = b.color.withValues(alpha: 0.75)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, r * 0.35),
      );
    }
    canvas.restore();

    // glossy highlight + rim
    canvas.drawOval(
      Rect.fromCenter(center: ctr + Offset(-r * 0.32, -r * 0.45), width: r * 0.7, height: r * 0.32),
      Paint()..color = Colors.white.withValues(alpha: 0.16),
    );
    canvas.drawCircle(
      ctr,
      r,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = Colors.white.withValues(alpha: 0.18),
    );

    // thinking / loading dots
    if (st == OrbState.thinking || st == OrbState.loading) {
      for (var i = 0; i < 3; i++) {
        final a = t * 3 + i * 2.094;
        final p = ctr + Offset(cos(a), sin(a)) * r * 1.5;
        canvas.drawCircle(p, r * 0.07, Paint()..color = Colors.white.withValues(alpha: 0.85));
      }
    }
  }

  @override
  bool shouldRepaint(covariant OrbPainter oldDelegate) => true;
}
