import 'dart:math';

/// Which rail/category a character belongs to on the Characters screen.
///
/// `gaming` is the original Free-Fire-style roster plus a few new recruits;
/// `anime` is the newer Naruto/Death-Note-style roster. The remaining values
/// exist so the Characters screen can show the full 7-tab sidebar from the
/// reference design even though only two tabs currently have content.
enum CharacterCategory { gaming, anime, donghua, marvels, kpop, politicians, banner }

/// One playable character portrait.
///
/// The artwork lives in `assets/characters/<name>.png`. Characters are the only
/// image assets in the whole game — everything else is still drawn with
/// CustomPainter, and nothing here needs the network.
class GameCharacter {
  const GameCharacter(this.name, {this.category = CharacterCategory.gaming});

  /// Display name, also used as the bot's name so a bot is always called the
  /// same thing as the face it is wearing.
  final String name;

  /// Which Characters-screen tab this character is filed under.
  final CharacterCategory category;

  String get asset => 'assets/characters/$name.png';

  @override
  String toString() => name;
}

/// The full roster shipped with the game.
///
/// Order matters: it is the order the horizontal Characters rail scrolls in,
/// and index 0 is the default pick for a brand-new player.
class Characters {
  Characters._();

  static const List<GameCharacter> all = [
    // ---- Gaming (original Free-Fire-style roster) ----
    GameCharacter('A124'),
    GameCharacter('A-Patroa'),
    GameCharacter('Alok'),
    GameCharacter('Alvaro'),
    GameCharacter('Andrew'),
    GameCharacter('Antonio'),
    GameCharacter('Caroline'),
    GameCharacter('Cla'),
    GameCharacter('Clu'),
    GameCharacter('D-Bee'),
    GameCharacter('Dasha'),
    GameCharacter('Dimitri'),
    GameCharacter('Ford'),
    GameCharacter('Hayato'),
    GameCharacter('Homer'),
    GameCharacter('Ignis'),
    GameCharacter('Iris'),
    GameCharacter('Joseph'),
    GameCharacter('Jota'),
    GameCharacter('K'),
    GameCharacter('Kapella'),
    GameCharacter('Kassie'),
    GameCharacter('Kelly'),
    GameCharacter('Kenta'),
    GameCharacter('Kiaros'),
    GameCharacter('Koda'),
    GameCharacter('Laura'),
    GameCharacter('Leon'),
    GameCharacter('Lila'),
    GameCharacter('Luna'),
    GameCharacter('Luqueta'),
    GameCharacter('Maro'),
    GameCharacter('Maxim'),
    GameCharacter('Miguel'),
    GameCharacter('Misha'),
    GameCharacter('Moco'),
    GameCharacter('Morse'),
    GameCharacter('Nairi'),
    GameCharacter('Nero'),
    GameCharacter('Nikita'),
    GameCharacter('Notora'),
    GameCharacter('Olivia'),
    GameCharacter('Orion'),
    GameCharacter('Oscar'),
    GameCharacter('Otho'),
    GameCharacter('Paloma'),
    GameCharacter('Rafel'),
    GameCharacter('Ray'),
    GameCharacter('Rin'),
    GameCharacter('Ryden'),
    GameCharacter('Santino'),
    GameCharacter('Shani'),
    GameCharacter('Shirou'),
    GameCharacter('Skyler'),
    GameCharacter('Soniya'),
    GameCharacter('Steffie'),
    GameCharacter('Suzy'),
    GameCharacter('Tatsuya'),
    GameCharacter('Thiva'),
    GameCharacter('Wolfrah'),
    GameCharacter('Wukong'),
    GameCharacter('Xayne'),
    // New gaming-style recruits.
    GameCharacter('Adam'),
    GameCharacter('Chrono'),
    GameCharacter('Victor'),
    GameCharacter('AberrantAphrodite'),

    // ---- Anime ----
    GameCharacter('Naruto', category: CharacterCategory.anime),
    GameCharacter('NarutoKid', category: CharacterCategory.anime),
    GameCharacter('Sasuke', category: CharacterCategory.anime),
    GameCharacter('Kakashi', category: CharacterCategory.anime),
    GameCharacter('Sakura', category: CharacterCategory.anime),
    GameCharacter('Hashirama', category: CharacterCategory.anime),
    GameCharacter('Madara', category: CharacterCategory.anime),
    GameCharacter('Minato', category: CharacterCategory.anime),
    GameCharacter('Jiraiya', category: CharacterCategory.anime),
    GameCharacter('Itachi', category: CharacterCategory.anime),
    GameCharacter('Obito', category: CharacterCategory.anime),
    GameCharacter('Pain', category: CharacterCategory.anime),
    GameCharacter('Shikamaru', category: CharacterCategory.anime),
    GameCharacter('L', category: CharacterCategory.anime),
    GameCharacter('LightYagami', category: CharacterCategory.anime),

    // ---- Marvels (superheroes) ----
    GameCharacter('IronMan', category: CharacterCategory.marvels),
    GameCharacter('CaptainAmerica', category: CharacterCategory.marvels),
    GameCharacter('Thor', category: CharacterCategory.marvels),
    GameCharacter('BlackWidow', category: CharacterCategory.marvels),
    GameCharacter('DoctorStrange', category: CharacterCategory.marvels),
    GameCharacter('ScarletWitch', category: CharacterCategory.marvels),
    GameCharacter('Thanos', category: CharacterCategory.marvels),
    GameCharacter('Deadpool', category: CharacterCategory.marvels),
    GameCharacter('Wolverine', category: CharacterCategory.marvels),
    GameCharacter('WonderWoman', category: CharacterCategory.marvels),
    GameCharacter('Supergirl', category: CharacterCategory.marvels),
    GameCharacter('Batman', category: CharacterCategory.marvels),
    GameCharacter('Superman', category: CharacterCategory.marvels),
    GameCharacter('SpiderMan', category: CharacterCategory.marvels),
    GameCharacter('CaptainMarvel', category: CharacterCategory.marvels),
    GameCharacter('Loki', category: CharacterCategory.marvels),
    GameCharacter('Mysterio', category: CharacterCategory.marvels),
    GameCharacter('DoctorDoom', category: CharacterCategory.marvels),

    // ---- Politicians ----
    GameCharacter('Modi', category: CharacterCategory.politicians),
    GameCharacter('Trump', category: CharacterCategory.politicians),
    GameCharacter('KimJongUn', category: CharacterCategory.politicians),
    GameCharacter('Meloni', category: CharacterCategory.politicians),
    GameCharacter('RahulGandhi', category: CharacterCategory.politicians),
    GameCharacter('Gadkari', category: CharacterCategory.politicians),
    GameCharacter('DhruvRathi', category: CharacterCategory.politicians),
  ];

  static int get count => all.length;

  /// All characters belonging to a single tab, in roster order.
  static List<GameCharacter> byCategory(CharacterCategory category) =>
      all.where((c) => c.category == category).toList();

  /// Look a character up by name, falling back to the first one so a corrupt
  /// or outdated saved preference can never crash the app.
  static GameCharacter byName(String? name) {
    if (name == null) return all.first;
    for (final c in all) {
      if (c.name == name) return c;
    }
    return all.first;
  }

  static String assetFor(String? name) => byName(name).asset;

  /// The category of [name], defaulting to [CharacterCategory.gaming] when
  /// the name is unknown/null.
  static CharacterCategory categoryOf(String? name) => byName(name).category;

  /// Pick [n] characters for the bots, guaranteed distinct from each other and
  /// from [exclude] (the human's pick), so no two seats ever wear the same
  /// face or carry the same name in a match.
  ///
  /// When [category] is given, bots are drawn only from that category's pool
  /// (e.g. a player who picked an Anime face plays against Anime bots), with
  /// a safe fallback to the whole roster if that category doesn't have
  /// enough distinct characters to fill every seat.
  static List<GameCharacter> pickBots(
    int n, {
    String? exclude,
    Random? rng,
    CharacterCategory? category,
  }) {
    final r = rng ?? Random();
    var pool = (category != null ? byCategory(category) : all)
        .where((c) => c.name != exclude)
        .toList();
    if (pool.length < n) {
      // Not enough distinct faces in that category — fall back to the full
      // roster so the match can still fill every seat with a unique face.
      pool = all.where((c) => c.name != exclude).toList();
    }
    pool.shuffle(r);
    // The roster is far bigger than the 3 bots a match can ever need, but be
    // defensive anyway rather than throwing on a short pool.
    if (n <= pool.length) return pool.take(n).toList();
    final out = <GameCharacter>[];
    while (out.length < n) {
      out.addAll(pool.take(min(pool.length, n - out.length)));
    }
    return out;
  }
}
