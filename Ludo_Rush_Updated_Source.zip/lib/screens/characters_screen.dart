import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../core/audio.dart';
import '../core/game_theme.dart';
import '../game/characters.dart' as roster;
import '../widgets/avatar.dart';

/// Characters screen — matches the Free-Fire-style reference:
/// LEFT: big character preview + name with yellow underline
/// MIDDLE: "Select Character" + scrollable **2-column** grid
/// RIGHT: category tabs + close button
class CharactersScreen extends StatefulWidget {
  const CharactersScreen({super.key, required this.selected});

  final String selected;

  @override
  State<CharactersScreen> createState() => _CharactersScreenState();
}

class _CharactersScreenState extends State<CharactersScreen> {
  late String _selected = widget.selected;
  late roster.CharacterCategory _category =
      roster.Characters.categoryOf(widget.selected);

  /// Preview can differ from equipped until user confirms by tapping again
  /// or we equip on every tap (current: equip on every tap).
  late String _preview = widget.selected;

  @override
  void initState() {
    super.initState();
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
  }

  @override
  void dispose() {
    SystemChrome.setPreferredOrientations(const [
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
    super.dispose();
  }

  Future<void> _pick(String name) async {
    Sfx.instance.uiClick();
    setState(() {
      _selected = name;
      _preview = name;
    });
    final p = await SharedPreferences.getInstance();
    await p.setString('character', name);
  }

  void _previewOnly(String name) {
    Sfx.instance.uiClick();
    setState(() => _preview = name);
  }

  void _selectCategory(roster.CharacterCategory c) {
    if (c == _category) return;
    Sfx.instance.uiClick();
    setState(() => _category = c);
  }

  void _back() {
    Sfx.instance.uiClick();
    Navigator.of(context).pop(_selected);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        Navigator.of(context).pop(_selected);
      },
      child: Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF1A3A5C),
                Color(0xFF0D1B2A),
                Color(0xFF0A1520),
              ],
            ),
          ),
          child: SafeArea(
            child: LayoutBuilder(
              builder: (context, cts) {
                final w = cts.maxWidth;
                final h = cts.maxHeight;
                final scale = (h / 360.0).clamp(0.7, 1.35);

                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // LEFT — hero preview
                    SizedBox(
                      width: w * 0.34,
                      child: _HeroPreview(
                        character: _preview,
                        scale: scale,
                      ),
                    ),

                    // MIDDLE — 2-col select grid
                    Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(
                          vertical: 10 * scale,
                          horizontal: 4 * scale,
                        ),
                        child: _SelectGrid(
                          category: _category,
                          selected: _selected,
                          preview: _preview,
                          scale: scale,
                          onTap: (name) {
                            _previewOnly(name);
                            _pick(name);
                          },
                        ),
                      ),
                    ),

                    // RIGHT — category sidebar
                    SizedBox(
                      width: (w * 0.18).clamp(100.0, 160.0),
                      child: _CategorySidebar(
                        category: _category,
                        scale: scale,
                        onSelect: _selectCategory,
                        onClose: _back,
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}

// =============================================================================
// LEFT — large character + name with yellow underline (reference style)
// =============================================================================
class _HeroPreview extends StatelessWidget {
  const _HeroPreview({required this.character, required this.scale});

  final String character;
  final double scale;

  @override
  Widget build(BuildContext context) {
    final c = roster.Characters.byName(character);
    final label = _categoryLabel(c.category);

    return Padding(
      padding: EdgeInsets.fromLTRB(12 * scale, 8 * scale, 4 * scale, 8 * scale),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Name + yellow underline bar
          Padding(
            padding: EdgeInsets.only(left: 4 * scale, top: 4 * scale),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  c.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 22 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                    letterSpacing: 0.4,
                    shadows: const [
                      Shadow(blurRadius: 8, color: Colors.black54),
                    ],
                  ),
                ),
                SizedBox(height: 4 * scale),
                Container(
                  height: 4 * scale,
                  width: 72 * scale,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(2),
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD54F), Color(0xFFFFA000)],
                    ),
                  ),
                ),
                SizedBox(height: 4 * scale),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 10 * scale,
                    fontWeight: FontWeight.w700,
                    color: Colors.white54,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 6 * scale),
          // Character full body on glowing platform
          Expanded(
            child: Stack(
              alignment: Alignment.bottomCenter,
              children: [
                // platform ring
                Positioned(
                  bottom: 8 * scale,
                  child: Container(
                    width: 160 * scale,
                    height: 40 * scale,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: RadialGradient(
                        colors: [
                          const Color(0xFFFFB300).withValues(alpha: 0.45),
                          const Color(0xFFFF6D00).withValues(alpha: 0.15),
                          Colors.transparent,
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: const Color(0xFFFF9800).withValues(alpha: 0.35),
                          blurRadius: 24 * scale,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                  ),
                ),
                // outer ring stroke
                Positioned(
                  bottom: 14 * scale,
                  child: Container(
                    width: 120 * scale,
                    height: 28 * scale,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                      border: Border.all(
                        color: const Color(0xFFFFA726).withValues(alpha: 0.7),
                        width: 2,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(bottom: 22 * scale),
                  child: CharacterBlend(
                    character: character,
                    alignment: Alignment.bottomCenter,
                    widthFactor: 1.55,
                    fallbackSeed:
                        character.codeUnits.fold(0, (a, b) => a + b),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  static String _categoryLabel(roster.CharacterCategory c) {
    switch (c) {
      case roster.CharacterCategory.gaming:
        return 'GAMING';
      case roster.CharacterCategory.anime:
        return 'ANIME';
      case roster.CharacterCategory.donghua:
        return 'DONGHUA';
      case roster.CharacterCategory.marvels:
        return 'MARVELS';
      case roster.CharacterCategory.kpop:
        return 'K-POP';
      case roster.CharacterCategory.politicians:
        return 'POLITICIANS';
      case roster.CharacterCategory.banner:
        return 'BANNER';
    }
  }
}

// =============================================================================
// MIDDLE — Select Character panel, 2-column scrollable grid
// =============================================================================
class _SelectGrid extends StatelessWidget {
  const _SelectGrid({
    required this.category,
    required this.selected,
    required this.preview,
    required this.scale,
    required this.onTap,
  });

  final roster.CharacterCategory category;
  final String selected;
  final String preview;
  final double scale;
  final ValueChanged<String> onTap;

  @override
  Widget build(BuildContext context) {
    final list = roster.Characters.byCategory(category);

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF0E1A28).withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(14 * scale),
        border: Border.all(
          color: const Color(0xFF2A4A6A).withValues(alpha: 0.9),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.35),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: EdgeInsets.fromLTRB(
              14 * scale,
              12 * scale,
              14 * scale,
              8 * scale,
            ),
            child: Text(
              'Select Character',
              style: TextStyle(
                fontSize: 15 * scale,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 0.3,
              ),
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? Center(
                    child: Text(
                      'Coming soon',
                      style: TextStyle(
                        fontSize: 13 * scale,
                        fontWeight: FontWeight.w800,
                        color: Colors.white38,
                      ),
                    ),
                  )
                : Padding(
                    padding: EdgeInsets.fromLTRB(
                      10 * scale,
                      0,
                      10 * scale,
                      10 * scale,
                    ),
                    child: GridView.builder(
                      physics: const BouncingScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10 * scale,
                        mainAxisSpacing: 10 * scale,
                        childAspectRatio: 0.92,
                      ),
                      itemCount: list.length,
                      itemBuilder: (_, i) {
                        final c = list[i];
                        final isSelected = c.name == selected;
                        final isPreview = c.name == preview;
                        return _SlotTile(
                          character: c.name,
                          selected: isSelected,
                          highlighted: isPreview,
                          scale: scale,
                          onTap: () => onTap(c.name),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _SlotTile extends StatelessWidget {
  const _SlotTile({
    required this.character,
    required this.selected,
    required this.highlighted,
    required this.scale,
    required this.onTap,
  });

  final String character;
  final bool selected;
  final bool highlighted;
  final double scale;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final borderColor = selected || highlighted
        ? const Color(0xFFFFC107)
        : const Color(0xFF3A6A9A);

    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        decoration: BoxDecoration(
          color: const Color(0xFF12263A),
          borderRadius: BorderRadius.circular(10 * scale),
          border: Border.all(color: borderColor, width: selected ? 2.4 : 1.6),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: const Color(0xFFFFC107).withValues(alpha: 0.35),
                    blurRadius: 10,
                    spreadRadius: 0.5,
                  ),
                ]
              : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8 * scale),
          child: Stack(
            fit: StackFit.expand,
            children: [
              // subtle inner gradient
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFF1A3550), Color(0xFF0C1C2C)],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(6 * scale),
                child: Image.asset(
                  roster.Characters.assetFor(character),
                  fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => Icon(
                    Icons.close,
                    color: Colors.white24,
                    size: 28 * scale,
                  ),
                ),
              ),
              if (selected)
                Positioned(
                  right: 4 * scale,
                  top: 4 * scale,
                  child: Container(
                    padding: EdgeInsets.all(2.5 * scale),
                    decoration: const BoxDecoration(
                      color: Color(0xFFFFC107),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.check,
                      size: 11 * scale,
                      color: const Color(0xFF1A1200),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// =============================================================================
// RIGHT — Characters header + close + category tabs
// =============================================================================
class _CategorySidebar extends StatelessWidget {
  const _CategorySidebar({
    required this.category,
    required this.scale,
    required this.onSelect,
    required this.onClose,
  });

  final roster.CharacterCategory category;
  final double scale;
  final ValueChanged<roster.CharacterCategory> onSelect;
  final VoidCallback onClose;

  static const _tabs = <(roster.CharacterCategory, String)>[
    (roster.CharacterCategory.gaming, 'Gaming'),
    (roster.CharacterCategory.anime, 'Anime'),
    (roster.CharacterCategory.donghua, 'Donghua'),
    (roster.CharacterCategory.marvels, 'Marvels'),
    (roster.CharacterCategory.kpop, 'K-pop'),
    (roster.CharacterCategory.politicians, 'Politicians'),
    (roster.CharacterCategory.banner, 'Banner'),
  ];

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(4 * scale, 6 * scale, 10 * scale, 8 * scale),
      child: Column(
        children: [
          // Title + close
          Row(
            children: [
              Expanded(
                child: Text(
                  'Characters',
                  style: TextStyle(
                    fontSize: 13 * scale,
                    fontWeight: FontWeight.w900,
                    color: Colors.white,
                  ),
                ),
              ),
              GestureDetector(
                onTap: onClose,
                child: Container(
                  width: 28 * scale,
                  height: 28 * scale,
                  decoration: const BoxDecoration(
                    color: Color(0xFFE53935),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.close,
                    size: 16 * scale,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 10 * scale),
          Expanded(
            child: ListView.separated(
              physics: const BouncingScrollPhysics(),
              itemCount: _tabs.length,
              separatorBuilder: (_, __) => SizedBox(height: 7 * scale),
              itemBuilder: (_, i) {
                final (cat, label) = _tabs[i];
                final sel = cat == category;
                return GestureDetector(
                  onTap: () => onSelect(cat),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 160),
                    height: 36 * scale,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8 * scale),
                      gradient: sel
                          ? const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Color(0xFFFFE082), Color(0xFFFFB300)],
                            )
                          : null,
                      color: sel ? null : const Color(0xFFE8EEF5),
                      boxShadow: sel
                          ? [
                              BoxShadow(
                                color: const Color(0xFFFFB300)
                                    .withValues(alpha: 0.4),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ]
                          : null,
                    ),
                    child: Text(
                      label,
                      style: TextStyle(
                        fontSize: 12 * scale,
                        fontWeight: FontWeight.w900,
                        color: sel
                            ? const Color(0xFF3A2800)
                            : const Color(0xFF2A3544),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
