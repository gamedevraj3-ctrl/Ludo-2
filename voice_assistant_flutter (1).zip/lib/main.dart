import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import 'brain.dart';
import 'orb.dart';
import 'speech.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const VoiceApp());
}

class VoiceApp extends StatelessWidget {
  const VoiceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voice Assistant',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(scaffoldBackgroundColor: const Color(0xFF05060B)),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  final SttService _stt = SttService();
  final VoiceService _voice = VoiceService();
  final Brain _brain = Brain();
  final OrbController _orb = OrbController();
  final Random _rng = Random();
  late final Ticker _ticker;

  OrbState _state = OrbState.loading;
  Lang _lang = Lang.hi;
  String _heard = '';
  String _reply = '';
  String _error = '';
  double _bump = 0;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onTick)..start();
    _boot();
  }

  void _onTick(Duration d) {
    final t = d.inMicroseconds / 1e6;
    _bump *= 0.9;
    double lv;
    switch (_state) {
      case OrbState.listening:
        lv = 0.15 + _bump * 0.8 + 0.12 * (0.5 + 0.5 * sin(t * 6));
        break;
      case OrbState.speaking:
        lv = 0.25 + _bump * 0.6 + 0.2 * (0.5 + 0.5 * sin(t * 8.3));
        break;
      default:
        lv = 0.0;
    }
    _orb.update(t, lv.clamp(0.0, 1.0).toDouble(), _state);
  }

  Future<void> _boot() async {
    try {
      await _voice.init();
      await _loadStt();
      if (mounted) setState(() => _state = OrbState.idle);
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Model load nahi hua: $e';
          _state = OrbState.idle;
        });
      }
    }
  }

  Future<void> _loadStt() async {
    if (mounted) setState(() => _state = OrbState.loading);
    await _stt.load(
      _lang,
      onPartial: (s) {
        if (!mounted) return;
        _bump = 1;
        setState(() => _heard = s);
      },
      onFinal: (s) {
        if (!mounted) return;
        _respond(s);
      },
    );
    if (mounted) setState(() => _state = OrbState.idle);
  }

  Future<void> _onTap() async {
    switch (_state) {
      case OrbState.idle:
        await _startListening();
        break;
      case OrbState.listening:
        await _stt.stop();
        if (mounted) setState(() => _state = OrbState.idle);
        break;
      case OrbState.speaking:
        await _voice.stop();
        if (mounted) setState(() => _state = OrbState.idle);
        break;
      default:
        break;
    }
  }

  Future<void> _startListening() async {
    setState(() {
      _heard = '';
      _error = '';
      _state = OrbState.listening;
    });
    try {
      await _stt.start();
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Mic start nahi hua: $e';
          _state = OrbState.idle;
        });
      }
    }
  }

  Future<void> _respond(String text) async {
    if (_state == OrbState.thinking || _state == OrbState.speaking) return;
    try {
      await _stt.stop();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _heard = text;
      _state = OrbState.thinking;
    });
    await Future<void>.delayed(const Duration(milliseconds: 350));
    final reply = _brain.handle(text, _lang);
    if (!mounted) return;
    setState(() {
      _reply = reply.text;
      _state = OrbState.speaking;
    });
    try {
      await _voice.speak(reply.text, _lang, onProgress: () => _bump = 1);
    } catch (_) {}
    try {
      await reply.action?.call();
    } catch (e) {
      if (mounted) setState(() => _error = 'Action nahi chala: $e');
    }
    if (mounted) setState(() => _state = OrbState.idle);
  }

  Future<void> _switchLang(Lang l) async {
    if (l == _lang || _state == OrbState.loading) return;
    try {
      await _voice.stop();
    } catch (_) {}
    setState(() => _lang = l);
    try {
      await _loadStt();
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Model load nahi hua: $e';
          _state = OrbState.idle;
        });
      }
    }
  }

  String get _label {
    final hi = _lang == Lang.hi;
    switch (_state) {
      case OrbState.loading:
        return hi ? 'मॉडल लोड हो रहा है…' : 'Model load ho raha hai…';
      case OrbState.idle:
        return hi ? 'बोलने के लिए ऑर्ब दबाइए' : 'Bolne ke liye orb dabao';
      case OrbState.listening:
        return hi ? 'सुन रही हूँ…' : 'Sun rahi hoon…';
      case OrbState.thinking:
        return hi ? 'सोच रही हूँ…' : 'Soch rahi hoon…';
      case OrbState.speaking:
        return hi ? 'बोल रही हूँ…' : 'Bol rahi hoon…';
    }
  }

  List<String> get _suggestions => _lang == Lang.hi
      ? ['समय क्या हुआ', '5 मिनट का टाइमर', 'यूट्यूब खोलो', 'एक चुटकुला सुनाओ', 'आज कौन सा दिन है']
      : ['time kya hua', '5 minute ka timer', 'open youtube', 'joke sunao', '12 plus 30'];

  @override
  void dispose() {
    _ticker.dispose();
    _stt.release();
    _voice.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  const Text('Voice Assistant', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: const Color(0xFF14301F), borderRadius: BorderRadius.circular(10)),
                    child: const Text('OFFLINE', style: TextStyle(fontSize: 10, color: Color(0xFF35D07F), fontWeight: FontWeight.w800)),
                  ),
                  const Spacer(),
                  ChoiceChip(label: const Text('हिंदी'), selected: _lang == Lang.hi, onSelected: (_) => _switchLang(Lang.hi)),
                  const SizedBox(width: 6),
                  ChoiceChip(label: const Text('English'), selected: _lang == Lang.en, onSelected: (_) => _switchLang(Lang.en)),
                ],
              ),
            ),
            Expanded(
              child: LayoutBuilder(
                builder: (context, box) {
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _onTap,
                    onPanUpdate: (d) => _orb.pointer(
                      (d.localPosition.dx / box.maxWidth - 0.5) * 2,
                      (d.localPosition.dy / box.maxHeight - 0.5) * 2,
                    ),
                    onPanEnd: (_) => _orb.release(),
                    onPanCancel: () => _orb.release(),
                    child: CustomPaint(painter: OrbPainter(_orb), size: Size.infinite),
                  );
                },
              ),
            ),
            Text(_label, style: const TextStyle(fontSize: 14, color: Color(0xFF97A3C0))),
            const SizedBox(height: 8),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  if (_heard.isNotEmpty)
                    Text(_heard, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: Color(0xFFBFC8E6))),
                  if (_reply.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(_reply, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                  ],
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(_error, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Color(0xFFFF8A80))),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 42,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  for (final s in _suggestions)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ActionChip(label: Text(s), onPressed: _state == OrbState.idle ? () => _respond(s) : null),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
          ],
        ),
      ),
    );
  }
}
