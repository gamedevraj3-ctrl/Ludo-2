import 'dart:math';

import 'package:flutter/material.dart';

enum OrbState { loading, idle, listening, thinking, speaking }

/// Holds time/level/state plus smoothed gaze and blink for the bot face.
class OrbController extends ChangeNotifier {
  double t = 0;
  double level = 0;
  double gx = 0;
  double gy = 0;
  double blink = 1;
  OrbState state = OrbState.loading;

  bool _follow = false;
  double _fx = 0;
  double _fy = 0;

  static double _h(int i, int k) {
    final x = sin(i * 127.1 + k * 311.7) * 43758.5453;
    return x - x.floorToDouble();
  }

  /// Eyes follow the finger (values from -1 to 1).
  void pointer(double x, double y) {
    _follow = true;
    _fx = x.clamp(-1.0, 1.0).toDouble();
    _fy = y.clamp(-1.0, 1.0).toDouble();
  }

  void release() {
    _follow = false;
  }

  void update(double time, double lv, OrbState st) {
    t = time;
    level = lv;
    state = st;
    double tx = 0;
    double ty = 0;
    if (_follow) {
      tx = _fx;
      ty = _fy;
    } else {
      switch (st) {
        case OrbState.idle:
          final k = (time / 2.4).floor();
          tx = (_h(k, 1) - 0.5) * 1.6;
          ty = (_h(k, 2) - 0.5) * 0.9;
          break;
        case OrbState.listening:
          tx = 0.05 * sin(time * 2);
          ty = 0.05;
          break;
        case OrbState.thinking:
          tx = 0.7;
          ty = -0.75;
          break;
        case OrbState.speaking:
          tx = sin(time * 0.8) * 0.3;
          ty = 0.05;
          break;
        case OrbState.loading:
          break;
      }
    }
    gx += (tx - gx) * 0.18;
    gy += (ty - gy) * 0.18;
    final ph = time % 3.3;
    blink = (ph > 3.0 && ph < 3.12) ? 1 - 0.92 * sin(pi * (ph - 3.0) / 0.12) : 1.0;
    notifyListeners();
  }
}

/// Minimal robot head with LED eyes that blink, look around and change per state.
class OrbPainter extends CustomPainter {
  OrbPainter(this.c) : super(repaint: c);
  final OrbController c;

  RRect _rr(double l, double t, double r, double b, double rad) =>
      RRect.fromRectAndRadius(Rect.fromLTRB(l, t, r, b), Radius.circular(rad));

  @override
  void paint(Canvas canvas, Size size) {
    final t = c.t;
    final lv = c.level;
    final st = c.state;
    final s = size.shortestSide * 1.08;
    final ctr = size.center(Offset.zero);

    double tilt = 0;
    double lean = 1;
    switch (st) {
      case OrbState.listening:
        tilt = 0.03 + 0.045 * sin(t * 0.9);
        lean = 1.03 + lv * 0.02;
        break;
      case OrbState.thinking:
        tilt = -0.06 + 0.02 * sin(t * 2);
        break;
      case OrbState.speaking:
        tilt = 0.02 * sin(t * 3.1) * (0.3 + lv);
        break;
      case OrbState.loading:
      case OrbState.idle:
        break;
    }

    canvas.save();
    canvas.translate(ctr.dx, ctr.dy + sin(t * 1.4) * s * 0.008);
    canvas.rotate(tilt);
    canvas.scale(lean, lean);

    final hw = s * 0.30;
    final hh = s * 0.25;

    // light level for ears / antenna
    double glow;
    switch (st) {
      case OrbState.listening:
        glow = 0.5 + 0.5 * lv;
        break;
      case OrbState.speaking:
        glow = 0.35 + 0.5 * lv;
        break;
      case OrbState.thinking:
        glow = 0.3 + 0.5 * sin(t * 10).abs();
        break;
      case OrbState.loading:
        glow = 0.25 + 0.2 * sin(t * 4);
        break;
      case OrbState.idle:
        glow = 0.25;
        break;
    }
    final gl = glow.clamp(0.0, 1.0).toDouble();
    final line = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    // antenna
    canvas.drawLine(
      Offset(0, -hh),
      Offset(0, -hh - s * 0.07),
      line
        ..strokeWidth = s * 0.008
        ..color = const Color(0xFF3A3E49),
    );
    canvas.drawCircle(
      Offset(0, -hh - s * 0.075),
      s * (0.016 + 0.006 * lv),
      Paint()..color = Color.fromRGBO(234, 244, 255, gl),
    );

    // ear pods
    for (final sg in [-1.0, 1.0]) {
      final x0 = sg < 0 ? -hw - s * 0.035 : hw - s * 0.005;
      final pod = _rr(x0, -s * 0.06, x0 + s * 0.04, s * 0.08, s * 0.02);
      canvas.drawRRect(pod, Paint()..color = const Color(0xFF171A21));
      canvas.drawRRect(
        pod,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = const Color.fromRGBO(255, 255, 255, 0.10),
      );
      canvas.drawRRect(
        _rr(x0 + s * 0.014, -s * 0.035, x0 + s * 0.026, s * 0.055, s * 0.006),
        Paint()..color = Color.fromRGBO(234, 244, 255, gl),
      );
    }

    // head
    final headRect = Rect.fromLTRB(-hw, -hh, hw, hh);
    final head = RRect.fromRectAndRadius(headRect, Radius.circular(s * 0.16));
    canvas.drawRRect(
      head,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF262932), Color(0xFF0B0C10)],
        ).createShader(headRect),
    );
    canvas.drawRRect(
      head,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..color = const Color.fromRGBO(255, 255, 255, 0.14),
    );
    // screen
    final inset = s * 0.035;
    final screen = _rr(-hw + inset, -hh + inset, hw - inset, hh - inset, s * 0.125);
    canvas.drawRRect(screen, Paint()..color = const Color(0xFF020305));
    canvas.drawRRect(
      screen,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.0
        ..color = const Color.fromRGBO(255, 255, 255, 0.06),
    );

    // eyes
    double ew = 1;
    double eh = 1;
    switch (st) {
      case OrbState.listening:
        ew = 1.08;
        eh = 1.12 + lv * 0.15;
        break;
      case OrbState.thinking:
        ew = 1.1;
        eh = 0.5 + 0.05 * sin(t * 9);
        break;
      case OrbState.speaking:
        eh = 0.92 + 0.08 * sin(t * 6) * (0.5 + lv);
        break;
      case OrbState.loading:
        ew = 1.25;
        eh = 0.12;
        break;
      case OrbState.idle:
        break;
    }
    final eyeW = s * 0.085 * ew;
    final eyeH = max(s * 0.13 * eh * c.blink, s * 0.012);
    final eyePaint = Paint()..color = const Color(0xFFEAF4FF);
    for (final sg in [-1.0, 1.0]) {
      final ex = sg * s * 0.15 + c.gx * s * 0.028 + (st == OrbState.loading ? sin(t * 3) * s * 0.05 : 0);
      final ey = -s * 0.035 + c.gy * s * 0.022;
      final far = 1 - 0.10 * (c.gx * sg).clamp(-1.0, 1.0).toDouble();
      final w = eyeW * far;
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(ex, ey), width: w, height: eyeH),
          Radius.circular(min(w, eyeH) / 2),
        ),
        eyePaint,
      );
    }

    // mouth
    final my = s * 0.115;
    final mp = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeWidth = s * 0.008
      ..color = const Color.fromRGBO(234, 244, 255, 0.6);
    if (st == OrbState.speaking) {
      for (var i = -3; i <= 3; i++) {
        final bh = s * (0.010 + 0.055 * lv * (0.55 + 0.45 * sin(t * 14 + i * 1.3)).abs());
        canvas.drawRRect(
          _rr(i * s * 0.024 - s * 0.006, my - bh / 2, i * s * 0.024 + s * 0.006, my + bh / 2, s * 0.006),
          Paint()..color = const Color.fromRGBO(234, 244, 255, 0.85),
        );
      }
    } else if (st == OrbState.thinking || st == OrbState.loading) {
      canvas.drawLine(Offset(-s * 0.03, my), Offset(s * 0.03, my), mp);
    } else if (st == OrbState.listening) {
      canvas.drawLine(Offset(-s * 0.025, my), Offset(s * 0.025, my), mp);
    } else {
      canvas.drawArc(
        Rect.fromCenter(center: Offset(0, my - s * 0.012), width: s * 0.09, height: s * 0.05),
        0.2,
        pi - 0.4,
        false,
        mp,
      );
    }

    // thinking dots above the head
    if (st == OrbState.thinking) {
      for (var i = -1; i <= 1; i++) {
        final dy = sin(t * 6 + i * 0.9) * s * 0.012;
        canvas.drawCircle(
          Offset(i * s * 0.045, -hh - s * 0.165 + dy),
          s * 0.011,
          Paint()..color = const Color.fromRGBO(234, 244, 255, 0.85),
        );
      }
    }

    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant OrbPainter oldDelegate) => true;
}
