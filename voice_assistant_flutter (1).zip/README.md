# Offline Hinglish Voice Assistant (Flutter)

- Robot bot (head + animated eyes) par tap karo, bolo. Ungli ghumao toh aankhein follow karti hain. Sab kuch phone par chalta hai, internet nahi chahiye.
- Speech-to-text: Vosk (Hindi small + Indian English small), TTS: phone ka apna engine.
- Commands: time, date, timer, alarm, call, app kholna, jod-ghata. Baaki sawaal: abhi built-in jawab.
- Phone mein Hindi/English offline TTS voice installed honi chahiye (Settings > Text-to-speech).
- APK GitHub Actions se banta hai (models build ke waqt download hote hain).
